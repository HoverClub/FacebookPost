
Facebook Post will post new topics, calendar events and, if you have SMF Gallery installed, new pictures to one or more Facebook wall, page or group.

* 	Create a new FaceBook app at https://developers.facebook.com/apps
		[b]Basic Info->App Domains->[/b][i]<Enter the domain name for your forum>[/i]
		[b]Select how your app integrates with Facebook->Website with Facebook Login->[/b][i]<your website domain again>[/i]

* Copy the [b]AppID[/b] and the [b]AppSecret[/b] and enter them into the Configuration Settings for this mod - then click SAVE to get to the next step.

* Click the link on the mod settings page to login to FB and get the required authorization token

* Select which forum boards you want to post topics from, whether you want calendar events posted and, if you have SMF Gallery installed, which galley categories you want new picture posted from.

* Select which FB wall(s), group(s) or page(s) you wish to post topics and events onto.

version history:
2.00
converted to using hooks for admin settings
1.03
added gallery picture post for SMF gallery
